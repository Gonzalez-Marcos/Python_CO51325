from setuptools import setup

setup(

    name = "paquete_marcos_gonzalez",
    version = "1.0",
    description = "Paquete para entrega Nº 2",
    author = "Marcos Gonzalez",
    author_email= "gonzalezmarcos_90@hotmail.com",

    packages = ["paquete_marcos_gonzalez"]

)